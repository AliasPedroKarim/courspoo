package fr.cesi.courspoogroovy;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourspooGroovyApplicationTests {

    @Autowired
    private

    @Test
    void contextLoads() {
    }

    // test getMatchs
    @Test
    void testGetMatchs() {

    }


}
