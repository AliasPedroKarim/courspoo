package fr.cesi.courspoogroovy.dao.match.model;

public class MatchDTO {
}
