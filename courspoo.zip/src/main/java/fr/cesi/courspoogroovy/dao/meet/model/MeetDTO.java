package fr.cesi.courspoogroovy.dao.meet.model;

public record MeetDTO(
        Integer numGagnant, Integer numPerdant, String lieuTournoi, Integer annee) {
}
