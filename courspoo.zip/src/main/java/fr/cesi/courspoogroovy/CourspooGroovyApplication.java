package fr.cesi.courspoogroovy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourspooGroovyApplication {

    public static void main(String[] args) {
        SpringApplication.run(CourspooGroovyApplication.class, args);
    }

}
