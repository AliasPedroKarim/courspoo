package fr.cesi.courspoogroovy.controllers.person.model;

public record Person(Integer id, String name, Integer birthYear, String nationality) {
}
