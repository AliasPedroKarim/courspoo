package fr.cesi.courspoogroovy.controllers.person.model;

public record NewPerson(String name, String lastname, Integer birthYear, String nationality) {
}