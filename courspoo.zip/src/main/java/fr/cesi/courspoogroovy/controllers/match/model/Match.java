package fr.cesi.courspoogroovy.controllers.match.model;

public record Match(Integer idWinner, Integer idLoser, String location, Integer sumAge) {
}